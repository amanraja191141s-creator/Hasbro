import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';

const root = process.cwd();
const css = fs.readFileSync(path.join(root, 'assets/css/app.css'), 'utf8');
const mirror = fs.readFileSync(path.join(root, 'www/assets/css/app.css'), 'utf8');
const pkg = JSON.parse(fs.readFileSync(path.join(root, 'package.json'), 'utf8'));

test('v99.06 release identity and measured reference geometry are present', () => {
  assert.equal(pkg.version, '1.99.20-v99.06');
  assert.equal(pkg.androidVersionCode, 1099135);
  assert.match(css, /--sa-ref-toolbar-height:52px/);
  assert.match(css, /--sa-ref-field-height:52px/);
  assert.match(css, /--sa-ref-keypad-height:\s*min\(48\.2dvh,\s*376px\)/);
  assert.match(css, /grid-auto-rows:98px/);
  assert.match(css, /grid-template-columns:repeat\(4,minmax\(0,1fr\)\)/);
  assert.match(css, /gap:10px !important/);
  assert.match(css, /height:var\(--sa-ref-keypad-height\)/);
});

test('root and Android web asset styles are identical', () => {
  assert.equal(css, mirror);
});

test('all reference tool screen sizing overrides avoid legacy 88px fields', () => {
  const measured = css.slice(css.lastIndexOf('v99.06 — measured 720x1560 reference-video geometry'));
  assert.match(measured, /min-height:52px !important; height:52px !important/);
  assert.match(measured, /min-height:56px !important; height:56px !important/);
  assert.match(measured, /font-size:16px !important/);
  assert.match(measured, /#screen-tools \.tools-reference-grid/);
  assert.match(measured, /#screen-units \.input-row/);
});
