import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
const html=fs.readFileSync('index.html','utf8');
const css=fs.readFileSync('assets/css/tool-reference-ui.css','utf8');
const tools=['currencies','units','discount','percent','salestax','agecalc','bodymetrics','date','fuelcost','fuelefficiency','gradeavg','hex','loan','salary','savings','sip','tip','unitprice','worldtime'];
test('all 19 calculator tools remain present',()=>{ for(const id of tools) assert.match(html,new RegExp(`id=\"screen-${id}\"`)); });
test('all shared calculator card families remain styled',()=>{
 for(const selector of ['.tool-input-group','.tool-result-content','.tool-form-content','.tool-result-content','.tool-field-group','.tool-form-content','.tool-result-content','.tool-result-content','.tool-result-content','.tool-field-row','.tool-field-row','.tool-form-content','.tool-result-content','.tool-data-row','.tool-data-group','.tool-hero-content','.tool-form-content','.tool-form-content','.tool-field-row','.tool-data-row','.tool-data-row','.tool-data-row','.tool-data-group']) assert.ok(css.includes(selector),`missing card family ${selector}`);
});
test('per-tool compound fields retain their authored content dimensions',()=>{
 assert.match(css,/#screen-salestax \.tool-form-content[\s\S]*?min-height:145px !important/);
 assert.match(css,/#screen-currencies \.tool-field-row[\s\S]*?height:122px !important/);
 assert.match(css,/#screen-bodymetrics \.tool-field-group[\s\S]*?min-height:145px !important/);
});
test('tool field and caret contracts remain in place',()=>{
 assert.match(css,/input-val-box\[data-tool-field=\"true\"\]/);
 assert.match(css,/input-cursor/);
});
