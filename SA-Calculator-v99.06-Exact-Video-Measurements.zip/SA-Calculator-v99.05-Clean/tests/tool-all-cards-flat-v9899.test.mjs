import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
const read=p=>fs.readFileSync(p,'utf8');
test('v99.01 HTML uses semantic tool groups rather than legacy card classes',()=>{
 const html=read('index.html');
 for(const old of ['premium-tool-card','calc-card','result-card','reference-form-card','reference-result-card','bmi-reference-field-card','gst-reference-card','savings-field','date-event-card','favorite-tool-card']) assert.ok(!html.includes(old),`Legacy card class remains in HTML: ${old}`);
 for(const id of ['tax-orig','tax-rate','tax-calculate','loan-p','loan-r','loan-tenure','body-metric-result','salary-net','sip-tab-calculator','tip-per-res','up-best-banner']) assert.ok(html.includes(`id="${id}"`),`Missing interactive/result node ${id}`);
 assert.ok(html.includes('class="tool-launch-item"')); assert.ok(html.includes('class="input-val-box'));
});
test('v99.01 CSS and JS no longer depend on legacy tool-card selectors',()=>{
 const css=read('assets/css/app.css')+'\n'+read('assets/css/tool-reference-ui.css'); const js=read('assets/js/app.js');
 for(const old of ['.premium-tool-card','.calc-card','.result-card','.reference-form-card','.reference-result-card','.bmi-reference-field-card','.gst-reference-card','.savings-field','.favorite-tool-card','.tool-card','.tool-result-card']) assert.ok(!css.includes(old),`Legacy CSS selector remains: ${old}`);
 for(const old of ['.premium-tool-card','.calc-card','.result-card','.reference-form-card','.reference-result-card','.savings-field','.favorite-tool-card']) assert.ok(!js.includes(old),`Legacy JS selector remains: ${old}`);
});
test('v99.01 cardless semantic containers preserve accessible focus and input/result contracts',()=>{
 const css=read('assets/css/tool-reference-ui.css')+'\n'+read('assets/css/app.css');
 assert.ok(css.includes('.tool-launch-item:focus-visible')); assert.ok(css.includes('.input-val-box')); assert.ok(css.includes('.tool-result-content'));
 const js=read('assets/js/app.js'); assert.ok(js.includes('tool-result-content')); assert.ok(js.includes('favorite-tool-item')); assert.ok(js.includes('tool-data-row'));
});
test('root and generated web stylesheet remain byte-identical',()=>assert.equal(read('assets/css/tool-reference-ui.css'),read('www/assets/css/tool-reference-ui.css')));
test('release identity and service-worker cache are synchronized',()=>{
 const pkg=JSON.parse(read('package.json')); assert.equal(pkg.version,'1.99.15-v99.01'); assert.equal(pkg.androidVersionCode,1099130);
 assert.ok(read('index.html').includes('1.99.15-v99.01')); assert.ok(read('service-worker.js').includes('sa-calculator-v99-01-card-css-purged-v9901'));
});
