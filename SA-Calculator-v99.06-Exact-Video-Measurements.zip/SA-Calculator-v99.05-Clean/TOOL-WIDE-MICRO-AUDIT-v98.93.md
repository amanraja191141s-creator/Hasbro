# SA Calculator v98.93 — All-Tools Micro-Level Audit

## Scope inspected
The v98.92 source archive was unpacked and inspected. The app contains 19 calculator/tool screens: Currency, Unit Converter, Discount, Percentage, GST, Age, Body Metrics, Date, Fuel Cost, Fuel Efficiency, Grade Average, Hexadecimal, Loan, Salary, Savings, SIP, Tip, Unit Price and World Time. The main and scientific calculators, settings, history, launcher and navigation surfaces were also checked for shared-field impact.

## Baseline
- The v98.92 automated suite passed 148 tests before this change.
- The tools already shared a docked keypad and custom input/caret renderer, but field semantics and empty-state handling were not initialized consistently across all screens.
- Placeholder rendering was strongly GST-specific; other tools could depend on older CSS selectors that do not match when the active custom caret is nested inside `.input-text`.
- Cursor cleanup on focus change was special-cased to the two GST fields, rather than consistently cleaning the previously active custom field.

## v98.93 changes
1. Added `initSharedToolFieldSemantics()` for all editable `.input-val-box` fields in tool screens.
2. Normalized role, accessible label fallback, decimal input mode, keyboard focusability, editable state, initial empty-state class and caret index.
3. Re-applied the normalization after previous-input restoration so restored values cannot leave stale placeholder state.
4. Generalized inactive-field caret cleanup to every custom numeric tool field, not only GST.
5. Added one shared field-level placeholder renderer driven by `data-placeholder` and `.is-empty`; the nested text span no longer needs to be empty for placeholder visibility.
6. Standardized custom field touch/selection behaviour: app-managed caret, no native Android text-selection callout, horizontal scrolling for long values, and theme-aware caret styling.
7. Preserved specialized screen layouts and each tool's existing calculation logic; this release does not replace tool-specific business formulas with GST formulas.
8. Added a new regression suite covering all 19 registered tool screens and the shared field contract.

## Tool-by-tool scope
- Currency: editable source amount, read-only converted amount, currency selectors and live conversion preserved.
- Unit Converter: source amount caret, From/To selectors, swap action and category selection preserved.
- Discount / Percentage / GST: existing result lifecycle and validation retained; shared empty state and caret contract applied.
- Age / Date: native date controls retained; custom numeric/date lifecycle is not replaced by a numeric keypad.
- Body Metrics: unit and gender controls retained; BMI/BMR formulas unchanged.
- Fuel Cost / Fuel Efficiency: existing positive-value and completeness validation retained.
- Grade Average: native subject-name and grade controls retained; credit input continues using the shared docked keypad.
- Hexadecimal: dedicated base-aware keyboard and caret retained; not forced into the decimal keypad.
- Loan: tenure picker and loan-specific validation retained.
- Salary / Savings / SIP / Tip / Unit Price: existing formulas and result commit/invalidation lifecycle retained.
- World Time: live clock and timezone controls retained; no numeric keypad forced onto clock display.

## Known limitations / not claimed
- Automated source tests do not prove visual pixel parity on every Android density or font scale.
- No physical Android device touch test, accessibility service test, APK build/signing, remote GitHub Actions run, or successful Chromium screenshot render was performed in this pass.
- Currency exchange freshness depends on the configured provider/network and is not guaranteed offline.
- This release does not claim zero bugs or guaranteed lag-free operation on all devices.
