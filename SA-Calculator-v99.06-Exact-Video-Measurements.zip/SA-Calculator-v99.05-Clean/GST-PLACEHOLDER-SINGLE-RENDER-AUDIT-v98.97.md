# GST placeholder single-render audit — v98.98

## Confirmed source issue
The GST amount and rate fields have a child-level placeholder renderer (`.input-text.is-empty::after`) and also inherit the shared parent-level placeholder renderer (`.input-val-box[data-tool-field="true"].is-empty::after`). If the parent empty state is stale during Android WebView input, both layers can paint placeholder text, making typed digits appear adjacent to `Enter amount` / `Add rate`.

## Correction
- Disable parent-level `::after` only for `#tax-orig` and `#tax-rate`.
- Keep the GST placeholder owned by the inline `.input-text` node beside the app-managed caret.
- Keep the existing shared input contract for all other tools unchanged.
- Add a release regression test for single-render ownership, empty-state synchronization, field markup, and release identity.

## Scope and verification boundary
This is a targeted correction supported by the supplied 2026-11-24 recordings and source inspection. It does not establish that every visual issue on every Android device is resolved. Physical WebView testing, screenshot comparison, APK build/signing and installation remain required.
