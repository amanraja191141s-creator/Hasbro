# SA Calculator v98.95 — All-tool card height reduction audit

## Requested change
- Previous card height: 114 CSS px.
- Reduction: 50 CSS px.
- New exact card height: **64 CSS px**.
- Maximum card width remains **430 CSS px**; on narrower screens width remains fluid to prevent horizontal overflow.

## Coverage
The existing v98.94 shared card-family selectors and exceptions are preserved. The height change applies to the same 68 statically declared visible card surfaces across all 19 calculator tools, plus dynamic GPA course rows, world-time rows and the previously covered date/event surfaces. Percentage input rows, GST rate/amount cards, Age fields and World Time grid items retain their specialized layout rules with the new 64px boundary. Tool launchers, keypad keys, dialogs and unrelated settings cards remain excluded as before.

## Content and interaction safeguards
Cards retain `box-sizing:border-box`, 430px maximum width, horizontal overflow containment, and contained vertical scrolling for dense content. Existing inner controls, custom cursor handling, calculations and tool-specific structures were not intentionally changed. Because 64px is substantially shorter, dense cards may require vertical scrolling inside the card; this keeps content reachable instead of clipping it.

## Release identity
- App version: `1.99.09-v98.95`
- Android versionCode: `1099115`
- Service worker cache: `sa-calculator-v98-95-all-tool-card-geometry-430x64-v9895`

## Validation
See `BUILD-VERIFICATION-v98.95.md` for actual test and packaging results. CSS geometry is in CSS pixels, not raw Android physical pixels. Physical-device screenshot measurement, touch/scroll validation, APK signing and remote Actions execution must be performed separately.
