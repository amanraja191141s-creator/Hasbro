# SA Calculator v98.86 — GST action-time layout and caret fix

## Scope
This release addresses the GST Calculator defects visible in `Screenrecording_20261124_121719.mp4` and the source-level issues found in the v98.85 project.

## Fixes
- Removed the redundant sibling `.input-cursor` nodes from GST amount and rate fields. The live caret is rendered only inside the `.input-text` span.
- Corrected raw-to-display caret mapping to ignore commas, currency/percent symbols, and whitespace while retaining the raw numeric caret index.
- Rebuilt the GST amount/rate/mode/state layout with deterministic normal-flow rows and explicit responsive grid tracks.
- Reserved a dedicated third grid column for 5% and 18% quick-rate controls; quick-rate buttons cannot share the state-selection row.
- Reset mode/state rows to static positioning and removed inherited transforms/insets/z-index that could cause overlap.
- Reduced oversized GST field heights and removed conflicting layout sizing from prior appended CSS layers.
- Made the result card content-height-driven, with visible overflow and scrollable parent content so lower tax rows remain accessible.
- Kept GST surfaces light regardless of the app theme; other tool themes and calculation behavior remain unchanged.
- Synchronized root and Android `www/` assets, release identity, service-worker cache namespace, and all workflow copies.
- Added regression coverage for duplicate caret markup, row separation, result clipping safeguards, caret mapping, and release identity.

## Release identity
- Package version: `1.99.00-v98.86`
- Android versionCode: `1099106`
- Service worker cache: `sa-calculator-v98-86-gst-action-layout-caret-v9886`

## Verification
- `npm test`: 120 tests passed, 0 failed.
- `node --check assets/js/app.js`: passed.
- `node --check assets/js/localization.js`: passed.
- Android web preparation: 13 required assets verified.
- Six workflow YAML copies parsed and are byte-identical.
- 21 release test entry points exist.
- Eight root/`www/` assets are byte-identical.

## Known limitations
No physical Android device test, APK build, remote GitHub Actions run, or visual browser automation was performed in this environment. CSS geometry and DOM contracts are regression-tested, but actual device rendering, touch caret placement, rotation, and frame-rate performance still require device validation.
