# Release notes — SA Calculator v99.06

- Calibrated the mobile tool UI from the user's 720×1560, 59.59-second reference recording.
- Fixed toolbar, input field, Tools tile, keypad key, keypad dock, spacing and bottom-banner dimensions using the measured physical-to-CSS scale.
- Preserved all 12 tools and existing calculation logic.
- Preserved the v99.05 viewport and Tools navigation corrections and the v99.05 CI release-file repair.
- Added `tests/reference-video-measurement-v9906.test.mjs`.
- Release identity: `1.99.20-v99.06`; Android versionCode `1099135`.
