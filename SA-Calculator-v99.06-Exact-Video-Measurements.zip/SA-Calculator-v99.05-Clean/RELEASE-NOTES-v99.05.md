# SA Calculator v99.05 — CI release-file repair

## Fix for GitHub Actions failure
- Added the missing `REFERENCE-VIDEO-UI-AUDIT-v99.05.md` release artifact. The workflow previously required this exact filename while the ZIP only included the historical v99.04 audit.
- Added the v99.05 viewport/Tools regression test to the workflow's required-file list.
- Added CI regression assertions for the audit document and viewport test file, preventing the same missing-artifact mismatch from returning.
- Synchronized `.github/workflows/main.yml` with `sa-calculator-v99.05-android.yml` byte-for-byte.

## Preserved release
- App version: `1.99.19-v99.05`
- Android versionCode: `1099134`
- Service-worker cache: `sa-calculator-v99-05-viewport-tools-navigation-v9905`
- Preserves the v99.05 viewport correction, visible Tools navigation, all 12 requested tools, and the v99.04 reference-video parity work.

## Verification
- `npm run build:web`: passed.
- `npm run test:release`: 55/55 passed.
- CI required-file list and release test entry points cross-checked.
- Physical device validation and remote GitHub Actions execution remain pending.
