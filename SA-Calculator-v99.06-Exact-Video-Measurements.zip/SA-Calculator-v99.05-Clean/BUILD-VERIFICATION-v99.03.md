# Build verification — SA Calculator v99.04

## Release identity
- App version: `1.99.17-v99.04`
- Android versionCode: `1099133`
- Service-worker cache: `sa-calculator-v99-03-exactly-12-tools-v9903`

## Verified
- Exact tool launcher count: 12
- Exact retained tool IDs: `currencies`, `units`, `salestax`, `loan`, `savings`, `salary`, `tip`, `sip`, `discount`, `percent`, `agecalc`, `bodymetrics`
- Removed tool screen IDs absent: `date`, `fuelcost`, `fuelefficiency`, `gradeavg`, `hex`, `unitprice`, `worldtime`
- Tool launcher destinations and `ALL_CALC_ITEMS` registry synchronized
- Favorites and search surfaces restored and backed by the 12-item registry
- Shared 15-key numeric keypad retained
- Currency Converter and Unit Converter initialization restored
- Removed date/GPA/world-time initialization and world-time polling not scheduled
- `node --check assets/js/app.js`: passed
- `node --check service-worker.js`: passed
- `npm run build:web`: passed; generated JS matches authoritative source
- `npm run test:release`: passed, 42 tests / 42 passed
- Android workflow YAML parsed successfully; standalone YAML is byte-identical to `.github/workflows/main.yml`
- Version, Android versionCode, workflow source selector, generated bundle and cache namespace synchronized

## Not claimed
- A physical Android device was not available for touch, layout, memory, and performance testing.
- The Android APK is produced by the GitHub Actions workflow; a CI-produced APK is not included in this source ZIP.
- Automated checks cannot guarantee zero bugs or zero lag on every device.

## Scope note
The seven removed tools are absent from the screen tree, launcher, routable registry, and startup initialization. Dormant historical helper functions remain in `assets/js/app.js` where they are not exposed or initialized; they were not blindly deleted because some shared event and formatting helpers have cross-tool dependencies.
