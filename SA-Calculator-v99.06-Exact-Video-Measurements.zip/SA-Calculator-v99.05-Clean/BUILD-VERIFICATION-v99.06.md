# Build verification — SA Calculator v99.06

## Source and release identity
- Reference video: `Screenrecording_20261124_185616.mp4` (59.5928 seconds, 720×1560 pixels, 41.9178 fps).
- Source base: `SA-Calculator-v99.05-CI-Release-File-Fix.zip`.
- App version: `1.99.20-v99.06`.
- Android versionCode: `1099135`.
- Service-worker cache: `sa-calculator-v99-06-measured-video-geometry-v9906`.

## Measured geometry
- Target logical viewport: approximately 360×780 CSS px at DPR 2.
- Secondary toolbar: 52 CSS px (about 104 physical px).
- Standard outlined fields: 52 CSS px (about 104 physical px).
- Dashboard tiles: 98 CSS px high (about 196 physical px), 8 CSS px column gap, 20 CSS px row gap, 12 CSS px outer gutter.
- Keypad: 4×4; 80 CSS px round keys (about 160 physical px); 10 CSS px horizontal and 14 CSS px vertical rhythm; 376 CSS px dock; 56 CSS px bottom banner reservation.
- Equals / unit action keys occupy the same two-row spans as the video.

## Automated verification
- `node --check assets/js/app.js`: passed.
- `npm run build:web`: passed; 13 required web assets prepared.
- `npm run test:release`: **58/58 passed**, 0 failed.
- GitHub workflow YAML parsed successfully.
- Workflow required-file check: **26/26 present and non-empty**.
- Standalone YAML and `.github/workflows/main.yml`: byte-identical.
- Root and `www/` copies of `index.html`, JS, CSS, service worker and manifest: byte-identical.
- HTML duplicate IDs: 0.
- Tool launchers: exactly 12.
- ZIP integrity: verified after packaging.

## Validation boundary
Source and automated release checks passed. A physical Android pixel-diff / touch session and a fresh remote GitHub Actions run were not available in this environment; they are not claimed as completed.
