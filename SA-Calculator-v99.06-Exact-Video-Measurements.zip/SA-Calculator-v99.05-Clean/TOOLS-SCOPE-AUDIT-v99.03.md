# Exact 12-tool scope audit — v99.03

## Retained tools (exactly 12)
1. Currency Converter (`currencies`)
2. Unit Converter (`units`)
3. GST Calculator (`salestax`)
4. Loan Calculator (`loan`)
5. Saving Calculator (`savings`)
6. Salary Calculator (`salary`)
7. Tip Calculator (`tip`)
8. SIP Calculator (`sip`)
9. Discount Calculator (`discount`)
10. Percentage Calculator (`percent`)
11. Age Calculator (`agecalc`)
12. BMI Calculator (`bodymetrics`)

## Removed from app navigation and screen tree
Date Calculator, Fuel Cost Calculator, Fuel Efficiency, Grade Average, Number Base Converter, Unit Price Calculator, and World Time Converter. Their screen containers and launcher destinations are absent. The old standalone implementation code remains dormant where shared historical helpers make blind deletion unsafe; these seven tools are not registered, rendered, routable, or initialized.

## Preserved
Main calculator, scientific calculator, History, Settings, themes, localization, 12-tool launcher/search/categories, favorites manager, and shared numeric keypad. Currency and Unit Converter initialization is enabled; percentage mode initialization is enabled. Removed date/GPA/world-time startup and polling are not invoked.

## Validation boundary
Automated source, syntax, regression, web-build, ZIP, and YAML checks are listed in `BUILD-VERIFICATION-v99.03.md`. Physical Android device testing and a CI-produced APK remain separate checks. No software can be truthfully guaranteed lag-free or bug-free on every device.
