# SA Calculator v99.06 — measured reference-video geometry audit

## Reference source and measurement method

- Source: `Screenrecording_20261124_185616.mp4` (the user's 59.5928-second recording).
- Native video frame: **720 × 1560 physical pixels**, 41.9178 fps.
- Measurements were taken from stable, non-transition frames at 18s (Tools dashboard), 4s (GST), 20s (Loan), 22s (Saving), 24s (Salary), 30–32s (SIP), 38–42s (Currency), 48s (Discount), and 52–56s (Unit Converter).
- The recorded viewport corresponds approximately to a 360 × 780 CSS-pixel viewport at device-pixel-ratio 2. Physical measurements below are therefore divided by 2 for CSS layout values. Browser/system status-bar overlays are not included in app content measurements.
- Transition frames and the currency loading overlay were excluded from geometry calibration.

## Reference geometry (physical pixels; CSS equivalent in parentheses)

| Element | Measured frame geometry | CSS target |
|---|---:|---:|
| Viewport | 720 × 1560 | 360 × 780 |
| Secondary-screen toolbar | ~104 px high | 52 px |
| Toolbar left inset | ~24 px | 12 px |
| Tool form left/right inset | ~24 px | 12 px |
| Standard outlined input | ~104 px high; width ~672 px | 52 px high; width ~336 px |
| Standard input corner radius | ~14 px | 7 px |
| Standard input-to-input gap | ~44 px | 22 px |
| Tool dashboard tile | ~213 × 196 px | ~106.5 × 98 px |
| Dashboard horizontal gap | ~16 px | 8 px |
| Dashboard vertical gap | ~40 px | 20 px |
| Dashboard outer side inset | ~24 px | 12 px |
| Keypad grid | 4 columns × 4 rows | 4 × 4 |
| Numeric/action key diameter | ~160 px | 80 px |
| Keypad horizontal/vertical gap | ~20 px | 10 px |
| Keypad left/right inset | ~8 px | 4 px |
| Keypad dock height | ~752 px on standard 4-row screens | ~376 px / 48.2% of 780px viewport |
| Bottom ad slot in captured state | ~112 px | ~56 px |
| Equals key | column 4, rows 3–4 | same |
| Unit converter action keys | CLR rows 1–2; DEL rows 3–4 | same |

## Screen-by-screen observations

- **Tools dashboard:** Finance & Money has 3 columns. First two rows contain GST/VAT, Loan, Saving, Salary, Tip and SIP. The ad unit follows those six cards; Currency and Discount follow the ad. Math & General Utilities contains Percentage and Unit; Health contains Age and BMI. Tile dimensions and category rhythm are preserved.
- **GST:** Original Price field; Add GST/Remove GST selector; Add GST Rate field; 5% and 18% quick presets; In-State/Out-of-State choices. Shared keypad begins at the same dock baseline as Loan/Salary/Discount.
- **Loan:** Loan Amount, Rate of Interest, Loan Tenure and Months/Years selector. Three outlined fields use the same measured field height and vertical rhythm.
- **Saving:** Saving Goal, Rate of Interest, Saving Period and Months/Years selector. The video shows the form geometry; it does not expose enough information to infer a different savings projection formula.
- **Salary:** Salary amount and Tax rate fields, with the same 52px CSS field sizing.
- **Tip:** Bill Amount, Rate of Tip and Number of Person fields, with shared keypad.
- **SIP:** Two pill tabs, SIP Calculator and SIP Delay Cost. Normal mode has Monthly SIP Amount, Investment Period and Expected Return Rate. Delay mode adds Delay in start from Today (Months). Three-field screens are allowed to scroll naturally above the fixed keypad.
- **Currency:** Two stacked outlined amount/currency rows; the active first row has blue outline; tall blue swap action spans the final two keypad rows.
- **Discount:** Original Amount and Discount Rate(%) fields; result appears after equals.
- **Unit Converter:** Category chooser first, then category workspace with two conversion rows, centered swap control, and tall CLR/DEL keypad actions. The equals key is absent in this mode.
- **Age and BMI:** The recording does not provide complete stable screens for all their input/result states; their existing controls and calculation logic are retained rather than guessed.

## v99.06 corrections

- Replaced the previous doubled logical-pixel sizing with CSS dimensions calibrated from the 720×1560 source frame at approximately DPR 2.
- Corrected the secondary toolbar from 88 CSS px to 52 CSS px (104 physical px).
- Corrected standard tool fields from 88 CSS px to 52 CSS px (104 physical px), with 22 CSS px inter-field rhythm.
- Corrected Tools cards to 98 CSS px high, 8 CSS px horizontal gaps, 20 CSS px row gaps and 12 CSS px side insets.
- Locked the shared keypad to a 4×4 grid with 80 CSS px round keys, 10 CSS px gaps, a 376 CSS px standard dock, and the correct tall-key spans.
- Kept the 56 CSS px banner reservation below the dock, with reduced-height viewport fallbacks.
- Applied the same measured CSS to root and `www/` web assets.
- Added a release regression test for the measured geometry and asset parity.
- Release identity: `1.99.20-v99.06`; Android versionCode `1099135`; service-worker cache `sa-calculator-v99-06-measured-video-geometry-v9906`.

## Verification boundary

The reference video was directly inspected and measured. Source-level tests and build checks validate CSS tokens, release identity, root/`www` parity, workflow references and archive integrity. A real-device pixel-diff, touch test and remote GitHub Actions execution require the user's Android device / GitHub runner and are not represented as completed here.
