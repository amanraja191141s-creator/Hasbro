# SA Calculator v98.99 — All Tool Cards Removed

## UI changes
- Removed card backgrounds, borders, rounded shells and shadows from all calculator tool form, field-wrapper and result-card families.
- Removed card chrome from Tools catalogue launcher tiles while preserving grid, icon, label, focus indication and click targets.
- Preserved input controls, cursor/caret layers, quick-rate and mode controls, result text, calculation actions, dialogs, keypad, navigation and Settings surfaces.
- Preserved v98.97 GST single-render placeholder fix and v98.96 content-first sizing.

## Release identity
- App version: `1.99.13-v98.99`
- Android versionCode: `1099119`
- Service worker cache: `sa-calculator-v98-99-all-tool-cards-flat-v9899`

## Validation scope
See `BUILD-VERIFICATION-v98.99.md`. Physical Android rendering, touch testing and remote GitHub Actions execution are not represented as completed unless separately run.
